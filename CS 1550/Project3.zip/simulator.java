import java.io.FileNotFoundException;
import java.util.*;
import java.io.File;

public class simulator{
	public static void main(String [] args) 
	{
		//declaring variables here and reading command line arguments
		String algorithm=args[1];
		String numFrame=args[3];
		String pageSize=args[5];
		String memorySplit=args[7];
		String trace=args[8];
		int nFrame=Integer.parseInt(numFrame);
		int pSize=Integer.parseInt(pageSize);
		String first="" + memorySplit.charAt(0);
		String second="" + memorySplit.charAt(2);
		int ams=Integer.parseInt(first);
		int bms=Integer.parseInt(second);
		//These variables are the number of frames for the two process. 
		//The number of frames is calculated using a simple formula.
		int fNumFrame= ((ams*nFrame)/(ams+bms));
		int sNumFrame=(bms*nFrame/(ams+bms));
		//finally the page offset is calculated by taking the log of the page size * 1024 since it is in KB and then dividing by log of 2
		int pageOffSet= (int) (Math.log(pSize*1024)/Math.log(2));
		//Depending on the command line arguments either the LRU or OPT method is called
		//Each method takes the number of frames for both processes, the page offset, the file name and the page size
		if(algorithm.equals("lru")){
			LRU(fNumFrame,sNumFrame,pageOffSet,trace,pageSize);
		}
		if(algorithm.equals("opt")){
			OPT(fNumFrame,sNumFrame,pageOffSet,trace,pageSize);
		}
		
	}
	public static void LRU(int fNumFrame,int sNumFrame ,int pageOffSet, String trace, String pageSize){
		//declaring variables for counting pagefaults, memory accesess and writes to disk
		int pageFaults=0;
		int writesToDisk=0;
		int memoryAccess=0;
		//These variables will be used for checking to see if an address exist inside a linked list
		boolean check=false;
		boolean otherCheck=false;
		//These variables are used to make sure that an address that was previously written too stays that way so we can properly count writes
		char safetyForBit=' ';
		char otherSafetyBit=' ';
		//These are used when eviciting someone
		int index=-1;
		int otherIndex=-1;
		//These linkedlist are used to store addresses for the two processes
		//info is an object I created that can store access type, address and process number
		LinkedList<info> firstProcess=new LinkedList<info>();
		LinkedList<info> secondProcess=new LinkedList<info>();
		try{
			//The file that was passed in will be read using some variable and scanners declared below
			File info= new File(trace);
			Scanner reader= new Scanner(info);
			while(reader.hasNextLine()){
				String line= reader.nextLine();
				//memoryAccess is incrementedsince each line of the file is a memory access
				memoryAccess++;
				//The below variables separate the line that was read into access type, process number and memory address
				char accessType=line.charAt(0);
				char processNumber=line.charAt(line.length()-1);
				 String fullAddress= line.substring(4,line.length()-2);
				Long actualAddress=Long.parseLong(fullAddress,16) >> pageOffSet;
				//This variable below is the correct address after shifting by the page offset
				  String realAddress=Long.toHexString(actualAddress);
				  //The info object is able to store all of the information associated with a file
				  //The info object allows you to store the address, access type and process number instead of keeping track seperately
					info store= new info(realAddress,accessType,processNumber);
					// if it is process 0 then is should enter into this if statement
					if(processNumber=='0'){
						//This for loop iterates over the linked list to see if it contains the address in the trace file
						//if it does then I set the boolean check to true and save the index of the address
						//I also check what kind of access was done on the address previously
						//If the access was a save then I also store it because we need to maintain it since the number of writes depends on the access type
						for(int i=0; i<firstProcess.size();i++){
							if(firstProcess.get(i).getAddress().equals(store.getAddress())){
								check=true;
								index=i;
								if(firstProcess.get(i).getAccessType()=='s'){
									safetyForBit='s';
								}else{
									safetyForBit=' ';
								}
								break;
							}else{
								check=false;
							}
						}
				if(!check){
					//If the linked list does not contain the address then that is a page fault
					pageFaults++;
					//if the linked list is not full and we can add an address then we do that. There is no need to evict since there is space available
					if(firstProcess.size()<fNumFrame){
						firstProcess.add(store);
					}else if(firstProcess.size()==fNumFrame){
					//if the linked list is full then we have to evict someone
					// Since this is LRU then we just need to evict the first item in the linked list
					//The first item is the least recently used but before we evict we need to check the accesstype and increment accrodingly
						if(firstProcess.get(0).getAccessType()=='s'){
							writesToDisk++;
						}
						//remove the first item and then add the new address
						firstProcess.remove();
						firstProcess.add(store);

					}
				}else{
					//if the linked list contains the address then we need to bring it to the front
					//we remove it and then we will later add it again
					firstProcess.remove(index);
					//before we add it back we have to check what kind of access has been made on it
					// we also have to check if it has previously been saved or written too which is where the safetyForBit comes in
					//if either are true then we have to indicate this by setting the access type before we add the address again
					if(accessType=='s' || safetyForBit=='s'){
						//setting the access type because one of the conditions is true
						store.setAccessType('s');
						//adding the address again because it is not longer the least recently used
							firstProcess.add(store);
						 } else {
							 //simply readding the address because none of the two previous conditons are satisfied 
							firstProcess.add(store);

						 }

				}
				
			 } else if(processNumber=='1'){
				 //If the process number is 1 then it should enter this if statement
				 //The steps below are exactly the same as the previous one with process 0
				 //The only difference is that different linked list and variables are used to seperate the two processes
				 
				for(int i=0; i<secondProcess.size();i++){
							if(secondProcess.get(i).getAddress().equals(store.getAddress())){
								otherCheck=true;
								otherIndex=i;
								if(secondProcess.get(i).getAccessType()=='s'){
									otherSafetyBit='s';
								}else{
									otherSafetyBit=' ';
								}
								break;
							}else{
								otherCheck=false;
							}
						}
				if(!otherCheck){
					pageFaults++;
					if(secondProcess.size()<sNumFrame){
						secondProcess.add(store);
					}else if(secondProcess.size()==sNumFrame){
						if(secondProcess.get(0).getAccessType()=='s'){
							writesToDisk++;
						}
						secondProcess.remove();
						secondProcess.add(store);

					}
				}else{
					secondProcess.remove(otherIndex);
					if(accessType=='s' || otherSafetyBit=='s'){
						store.setAccessType('s');
							secondProcess.add(store);
						 } else {
							secondProcess.add(store);

						 }

				}
			  }
			}
			//These statements below print out the correct page size, memory accesses and writes to disk 
			System.out.println("Algorithm: LRU");
			int total=fNumFrame +sNumFrame;
			System.out.println("Number of frames: " + total);
			System.out.println("Page size: " + pageSize + " KB" );
			System.out.println("Total memory accesses: " + memoryAccess);
	    	System.out.println("Total page faults: " + pageFaults);
			System.out.println("Total writes to disk: " + writesToDisk);

			reader.close();
		}catch(FileNotFoundException e){
			System.out.println("error occured");
		}

	}
	public static void OPT(int fNumFrame,int sNumFrame ,int pageOffSet, String trace, String pageSize){
		//The variables below are used to keep track of page faults, writes to disk and memory access
		int pageFaults=0;
		int writesToDisk=0;
		int memoryAccess=0;
		//These are used to see if a linked list contains an address or not
		boolean check=false; 
		boolean otherCheck=false;
		//These variables are used to make sure that an address that was previously written too stays that way so we can properly count writes
		char safetyForBit=' ';
		char otherSafetyBit=' ';
		int index=-1;
		int otherIndex=-1;
		//This variable is used to create a hash table that stores all of the line numbers for each address
		int lineNumber=0;
		int ln=0;
		//These variables are used to determine the address with the largest next memory access 
		int max=0;
		int sMax=0;
		//These variables are used when eviciting 
		int evicitonIndex=0;
		int sEvictionIndex=0;
		//These are linked list that will contain addresses for two processes
		LinkedList<info> firstProcess=new LinkedList<info>();
		LinkedList<info> secondProcess=new LinkedList<info>();
		//These hashtables contain all of the line numbers that the addresses will be accessed at for the two processes
		// The hashtables are built using addresses as keys and the values are linked list that will store line numbers
		Hashtable<String,LinkedList<Integer>> storage= new Hashtable<String,LinkedList<Integer>>();
		Hashtable<String,LinkedList<Integer>> sStorage=new Hashtable<String,LinkedList<Integer>>();
		try{
		   //This reads the file line by line and build the two hash tables
			File input= new File(trace);
			Scanner scan= new Scanner(input);
			while(scan.hasNextLine()){
				String all=scan.nextLine();
				lineNumber++;
				char accessType=all.charAt(0);
				char processNumber=all.charAt(all.length()-1);
				 String fullAddress= all.substring(4,all.length()-2);
				Long actualAddress=Long.parseLong(fullAddress,16) >> pageOffSet;
				  String realAddress=Long.toHexString(actualAddress);
				  if(processNumber=='0'){
					  //if it is process 0 then we check if the hash table for process 0 contains the address
				if(!storage.containsKey(realAddress)){
			// if the hash table does not contain the address then we create linked list that will store all of the line numbers for that address
						LinkedList<Integer> series=new LinkedList<Integer>();
						series.add(lineNumber);
						//Then we add the linked list to the hash table
					storage.put(realAddress,series);	
					}else{
						// if the hash table contains the address then we just add the new line number it will be accessed at
						storage.get(realAddress).add(lineNumber);
					}
				}else if(processNumber=='1'){
					//This is similar to process 0 only with a different hash table
						if(!sStorage.containsKey(realAddress)){
						LinkedList<Integer> series=new LinkedList<Integer>();
						series.add(lineNumber);
					sStorage.put(realAddress,series);	
					}else{
						sStorage.get(realAddress).add(lineNumber);
					}
				}

			} 
			scan.close();
	   }catch(FileNotFoundException e){
			System.out.println("File not found");
		}

  try{

	  		//The steps below are exactly the same as LRU the only difference is eviciton
			File info= new File(trace);
			Scanner reader= new Scanner(info);
			while(reader.hasNextLine()){
				String line= reader.nextLine();
				memoryAccess++;
				ln++;
				char accessType=line.charAt(0);
				char processNumber=line.charAt(line.length()-1);
				 String fullAddress= line.substring(4,line.length()-2);
				Long actualAddress=Long.parseLong(fullAddress,16) >> pageOffSet;
				  String realAddress=Long.toHexString(actualAddress);
					info store= new info(realAddress,accessType,processNumber);

					if(processNumber=='0'){
						for(int i=0; i<firstProcess.size();i++){
							if(firstProcess.get(i).getAddress().equals(store.getAddress())){
								check=true;
								index=i;
								if(firstProcess.get(i).getAccessType()=='s'){
									safetyForBit='s';
								}else{
									safetyForBit=' ';
								}
								break;
							}else{
								check=false;
							}
						}
				if(!check){
					pageFaults++;
					if(firstProcess.size()<fNumFrame){
						firstProcess.add(store);
					}else if(firstProcess.size()==fNumFrame){
						// If the linked list is full then we must evict an address
						for(int i=0; i<fNumFrame; i++){
							// we iterate over the linked list and for every address in the linked list we check the hash table
							// we use the address as a key and the value we get is a linked list that contains all of the line numbers for that address
							String key=firstProcess.get(i).getAddress();
							LinkedList<Integer> temp=storage.get(key);
							//if the linked list that is returned is empty then that address is evicited because it no longer appears in the future
							// otherwise we look at the first value of the linked list that is returned since that number is the next line the address will be accessed at
							// we evict the address with the largest next memory access 
							if(temp.size()==0){
								evicitonIndex=i;
								break;
							}else if(temp.get(0)>max){
								max=temp.get(0);
								evicitonIndex=i;
							}

						}
						//Before we evict we check the access type
						//if it was written too then we increment writes to disk
						 if(firstProcess.get(evicitonIndex).getAccessType()=='s'){
						 	writesToDisk++;
						 }
						 //we evict at the index found from the for loop and then add the new address
						 firstProcess.remove(evicitonIndex);
						 firstProcess.add(store);
						 //we reset max and index before the next line is read
						max=0;
						evicitonIndex=0;

					}
				}else{
					firstProcess.remove(index);
					if(accessType=='s' || safetyForBit=='s'){
						store.setAccessType('s');
							firstProcess.add(store);
						 } else {
							firstProcess.add(store);

						 }

				}
				
			 } else if(processNumber=='1'){
			
				for(int i=0; i<secondProcess.size();i++){
							if(secondProcess.get(i).getAddress().equals(store.getAddress())){
								otherCheck=true;
								otherIndex=i;
								if(secondProcess.get(i).getAccessType()=='s'){
									otherSafetyBit='s';
								}else{
									otherSafetyBit=' ';
								}
								break;
							}else{
								otherCheck=false;
							}
						}
				if(!otherCheck){
					pageFaults++;
					if(secondProcess.size()<sNumFrame){
						secondProcess.add(store);
					}else if(secondProcess.size()==sNumFrame){
							// the evicition process is exactly the same as with process 1 only different variables
						for(int i=0; i<sNumFrame; i++){ 
							String key=secondProcess.get(i).getAddress();
							LinkedList<Integer> temp=sStorage.get(key);
							if(temp.size()==0){
								sEvictionIndex=i;
								break;
							}else if(temp.get(0)>sMax){
								sMax=temp.get(0);
								sEvictionIndex=i;
							}

						}
					
						 if(secondProcess.get(sEvictionIndex).getAccessType()=='s'){
						 	writesToDisk++;
						 }
						 secondProcess.remove(sEvictionIndex);
						 secondProcess.add(store);
						sMax=0;
						sEvictionIndex=0;
					}
				}else{
					secondProcess.remove(otherIndex);
					if(accessType=='s' || otherSafetyBit=='s'){
						store.setAccessType('s');
							secondProcess.add(store);
						 } else {
							secondProcess.add(store);

						 }
				}
			  }		
					//With every iteration we remove line numbers from the two hash tables
					//This is done so that the first value of the linked lists in the hash tables is the next memory access
					// linked lists that are empty mean that the address associated with it will no longer be accessed in the future
					if(store.getProcessNumber()=='0'){
						storage.get(store.getAddress()).remove(Integer.valueOf(ln));

					}else{
					sStorage.get(store.getAddress()).remove(Integer.valueOf(ln));

					}
			}

			//The statements below print out the correct page faults, memory accesses and writes to disk
			System.out.println("Algorithm: OPT");
			int total=fNumFrame +sNumFrame;
			System.out.println("Number of frames: " + total);
			System.out.println("Page size: " + pageSize + " KB" );
			System.out.println("Total memory accesses: " + memoryAccess);
	    	System.out.println("Total page faults: " + pageFaults);
			System.out.println("Total writes to disk: " + writesToDisk);
			//System.out.println(firstProcess.toString());
			reader.close();
		}catch(FileNotFoundException e){
			System.out.println("error occured");
     }
	}
	public static void swap(int[] arr, int index){
			int temp=arr[arr.length-1];
			arr[arr.length-1]=arr[index];
			arr[index]=temp;
		}
	public static void shift(int[] arr, int start, int capacity){
		for(int i=start; i<capacity-1;i++){
			arr[i]=arr[i+1];
		}
	}

}
