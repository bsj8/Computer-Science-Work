public class info{
    private String address;
    private char accessType;
    private char processNumber;
    public info(String address, char accessType, char processNumber){
        this.address=address;
        this.accessType=accessType;
        this.processNumber=processNumber;
    }
    public String getAddress(){
        return address;
    }
    public char getAccessType(){
        return accessType;
    }
    public char getProcessNumber(){
        return processNumber;
    }
    public void setAddress(String pAddress){
         address= pAddress;
    }
    public void setAccessType(char pAccessType){
         accessType=pAccessType;
    }
    public void setProcessNumber(char pProcessNumber){
         processNumber= pProcessNumber;
    }

}