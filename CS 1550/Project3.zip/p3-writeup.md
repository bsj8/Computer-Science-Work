Based on the data collected and the graphs made. It appears that opt performs a lot better than lru. This is likely because opt is more efficient as it looks ahead and evicts based on future memory accesses. Opt consistently performed better than lru with every test. However, I did notice as the page size and number of frames increased opt began to perform similar to lru. I believe this is likely because as the number of frames increases there is more space for addresses and fewer evictions making them perform the same.

![image](https://user-images.githubusercontent.com/56082714/163258712-50aa6dbf-3d70-4216-bf21-755515f82ab0.png)
![image](https://user-images.githubusercontent.com/56082714/163258680-9743f294-897d-47a1-9d15-d018654e309a.png)
 ![image](https://user-images.githubusercontent.com/56082714/163258479-135b3577-c2a0-4fc3-b4ce-b6540d97a813.png)
 ![image](https://user-images.githubusercontent.com/56082714/163258633-574ccdce-4861-4947-8578-8e81c1e7fca8.png)


 
 
  

