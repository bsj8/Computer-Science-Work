#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

#include "museumsim.h"

//
// In all of the definitions below, some code has been provided as an example
// to get you started, but you do not have to use it. You may change anything
// in this file except the function signatures.
//


struct shared_data {
	// Add any relevant synchronization constructs and shared state here.
	// For example:
	//Below are all the shared variables such as mutexes, condition variables and ints that will later be used
	     pthread_mutex_t ticket_mutex;
		 pthread_cond_t  visitorsCond;
		 pthread_cond_t  guidesCond;
		pthread_cond_t  guides_LeaveCond;
	     int tickets;
		 int num_guides;
		 int num_visitors;
		 int guidesInside;
		 int visitorsInside;
		 int flag;
		 int guideWaiting;
		 int guidesOutside;

};

static struct shared_data shared;


/**
 * Set up the shared variables for your implementation.
 * 
 * `museum_init` will be called before any threads of the simulation
 * are spawned.
 */
void museum_init(int num_guides, int num_visitors)
{
	//Below all of the shared data is initialized 
	 pthread_mutex_init(&shared.ticket_mutex, NULL); 
	 pthread_cond_init(&shared.visitorsCond,NULL);
	 pthread_cond_init(&shared.guidesCond,NULL);
	pthread_cond_init(&shared.guides_LeaveCond,NULL);
	 shared.tickets = MIN(VISITORS_PER_GUIDE * num_guides, num_visitors);
	 shared.num_guides=num_guides;
	 shared.num_visitors=num_visitors;
	 shared.guidesInside=0;
	 shared.visitorsInside=0;
	 shared.flag=0;
	 shared.guideWaiting=0;
	 shared.guidesOutside=0;
}


/**
 * Tear down the shared variables for your implementation.
 * 
 * `museum_destroy` will be called after all threads of the simulation
 * are done executing.
 */
void museum_destroy()
{
	// pthread_mutex_destroy(&shared.ticket_mutex);
	//Below all of the shared data is reset
	pthread_mutex_destroy(&shared.ticket_mutex);
	pthread_cond_destroy(&shared.visitorsCond);
	pthread_cond_destroy(&shared.guidesCond);
	pthread_cond_destroy(&shared.guides_LeaveCond);
	shared.tickets = 0;
	 shared.num_guides=0;
	 shared.num_visitors=0;
	 shared.guidesInside=0;
	 shared.visitorsInside=0;
	 shared.flag=0;
	 shared.guideWaiting=0;
	 shared.guidesOutside=0;


}


/**
 * Implements the visitor arrival, touring, and leaving sequence.
 */
void visitor(int id)
{
	// I first start out by locking the mutex to prevent race congition and then I call visitor_arrives(id)
	pthread_mutex_lock(&shared.ticket_mutex);
	 visitor_arrives(id);
	 //if there are no tickets the visitors unlocks the mutex and leaves because it cannot tour
	if(shared.tickets==0){
		visitor_leaves(id);
		pthread_mutex_unlock(&shared.ticket_mutex);
		return;
	}
	// if there are tickets then I decrement the ticket int and then I make the process wait
	//I increment a flag to show how many visitors are waiting 
	shared.tickets-=1;
			shared.flag+=1;
			if(shared.guideWaiting!=0){
				//If there are any guides waiting on visitors then they will be woken up and then begin admitting visitors
			pthread_cond_signal(&shared.guidesCond);
			}
			//visitor is made to wait here
			pthread_cond_wait(&shared.visitorsCond, &shared.ticket_mutex);
			//Before the visitors tours I unlock the mutex and then I let the visitor tour and then relock the mutex
	 pthread_mutex_unlock(&shared.ticket_mutex);
	 visitor_tours(id);
	pthread_mutex_lock(&shared.ticket_mutex);
	//reduce the amount of visitors inside before they leave and then let the visitor leave
	 shared.visitorsInside-=1;
	 visitor_leaves(id);
	 //wake up any sleeping guides that were waiting on visitors to leave
	 if(shared.visitorsInside==0){
		 printf("no visitors inside\n");
		 pthread_cond_broadcast(&shared.guidesCond);
	 }
	 pthread_mutex_unlock(&shared.ticket_mutex);
}

/**
 * Implements the guide arrival, entering, admitting, and leaving sequence.
 */
void guide(int id)
{
	//Start by locking the mutex to prevent shared vairables from being affected
	pthread_mutex_lock(&shared.ticket_mutex);
	int admitted=0;
	guide_arrives(id);
	//after guide arrives if there are already maximumu guides inside then it has to wait
	 if(shared.guidesInside==GUIDES_ALLOWED_INSIDE){
		 shared.guidesOutside+=1;
		 pthread_cond_wait(&shared.guides_LeaveCond, &shared.ticket_mutex);
	 }
	 guide_enters(id);
	 shared.guidesInside+=1;
	// guide_admits(id);
	//otherwise after guide enters it admits visitors until its accepted the maximum visitors
	//if it has not accepted the maximum visitor it will wait until more visitors arrive
	//if there are no more visitors or tickets then the guide will break from the loop and try to leave
	while(admitted!=VISITORS_PER_GUIDE){
		printf(" visitors not yet served %d\n", shared.flag);
		if(shared.flag!=0){
			shared.flag-=1;
			admitted++;
		    shared.visitorsInside+=1;	
			guide_admits(id);
			pthread_cond_signal(&shared.visitorsCond);
			//guide_admits(id);
		}else if(shared.tickets!=0){
			shared.guideWaiting+=1;
		 pthread_cond_wait(&shared.guidesCond, &shared.ticket_mutex);
		 shared.guideWaiting-=1;
		}else{
			break;
		}
	}
	// guide_leaves(id);
	//the guide cannot leave if there are still visitors inside
	// if there are no visitors inside and all the guides are done then the guides can leave 
	// as the guides leave they will wake up any waiting guides outside
	while(shared.visitorsInside!=0){
		pthread_cond_wait(&shared.guidesCond, &shared.ticket_mutex);
	} 
		shared.guidesInside-=1;
		guide_leaves(id);
		if(shared.guidesOutside!=0 && shared.guidesInside==0){
			shared.guidesOutside-=1;
		pthread_cond_signal(&shared.guides_LeaveCond);
		}
	 pthread_mutex_unlock(&shared.ticket_mutex);
}
