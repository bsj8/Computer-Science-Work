#define FUSE_USE_VERSION 26
#define MIN(x, y) (((x) < (y)) ? (x) : (y))


#include <errno.h>
#include <fcntl.h>
#include <fuse.h>
#include <stdio.h>
#include <string.h>

#include "cs1550.h"

FILE * fp;

/**
 * Called whenever the system wants to know the file attributes, including
 * simply whether the file exists or not.
 *
 * `man 2 stat` will show the fields of a `struct stat` structure.
 */
static int cs1550_getattr(const char *path, struct stat *statbuf)
{
	(void) statbuf;



	// Clear out `statbuf` first -- this function initializes it.
	memset(statbuf, 0, sizeof(struct stat));

	// Check if the path is the root directory.
	if (strcmp(path, "/") == 0) {
		statbuf->st_mode = S_IFDIR | 0755;
		statbuf->st_nlink = 2;

		return 0; // no error
	}
	char directory[MAX_FILENAME +1];
	char filename[MAX_FILENAME+1];
	char extension[MAX_EXTENSION+1];
	int flag;
	flag=sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);

	// Check if the path is a subdirectory.
		if (flag==1) {
			int exist=-1;
			struct cs1550_root_directory root_dir;
				fseek(fp,0,SEEK_SET);
			fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
			for(size_t i=0;i<root_dir.num_directories;i++){
				struct cs1550_directory compare = root_dir.directories[i]; 
				exist=strncmp(compare.dname,directory,MAX_FILENAME+1);
				if(exist==0){
					break;
				}
			}
			if(exist==0){
			statbuf->st_mode = S_IFDIR | 0755;
			statbuf->st_nlink = 2;
			return 0; // no error
			}else{
				return -ENOENT;
			}
			
		}

	// Check if the path is a file.
		if (flag>1) {
			int fExist=-1;
			int eCheck=-1;
			int tExist=-1;
			struct cs1550_root_directory root_dir;
				fseek(fp,0,SEEK_SET);
			fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
			struct cs1550_directory compare;
			size_t fileIndex=-1;
			for(size_t i=0;i<root_dir.num_directories;i++){
				 compare = root_dir.directories[i]; 
				 //potential issue below 
				fExist=strncmp(compare.dname,directory,MAX_FILENAME+1);
				if(fExist==0){
					break;
				}
			}
				if(fExist==0){
					 fileIndex=compare.n_start_block;
				}else{
					return -ENOENT;
				}
				
				fseek(fp,fileIndex * BLOCK_SIZE,SEEK_SET);
				struct cs1550_directory_entry file_dir;
				struct cs1550_file_entry test;
				fread (&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);
				for(size_t i=0;i<file_dir.num_files;i++){
					test=file_dir.files[i];
					tExist=strncmp(test.fname,filename,MAX_FILENAME+1);
					//printf(test.fname);
					//printf(filename);
					if(strcmp(test.fext,"")!=0)
					eCheck=strncmp(test.fext,extension,MAX_EXTENSION+1);
					//printf("%ld",eCheck);
					//printf(test.fext);
					//printf(extension);
					if(tExist==0){
						if(strcmp(test.fext,"")!=0){
							if(eCheck==0)
								break;
						}else{
							break;
						}
					}
				}
				if(tExist==0){
					if(strcmp(test.fext,"")!=0){
						if(eCheck!=0)
						return -ENOENT;
					}
			// Regular file
			statbuf->st_mode = S_IFREG | 0666;
	
			// Only one hard link to this file
			statbuf->st_nlink = 1;
	
			// File size -- replace this with the real size
			statbuf->st_size =test.fsize;
			return 0; // no error
				}else{

						return -ENOENT;

				}
		}

	// Otherwise, the path doesn't exist.
	return -ENOENT;
}

/**
 * Called whenever the contents of a directory are desired. Could be from `ls`,
 * or could even be when a user presses TAB to perform autocompletion.
 */
static int cs1550_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
			  off_t offset, struct fuse_file_info *fi)
{
	(void) offset;
	(void) fi;

	char directory[MAX_FILENAME +1];
	char filename[MAX_FILENAME+1];
	char extension[MAX_EXTENSION+1];
	int flag=-1;
	int exist=-1;
	int fileIndex=-1;
	flag=sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);

	struct cs1550_root_directory root_dir;
			fseek(fp,0,SEEK_SET);
			fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
			struct cs1550_directory compare;
	// The filler function allows us to add entries to the listing.
	filler(buf, ".", NULL, 0);
	filler(buf, "..", NULL, 0);

	if (strcmp(path, "/") == 0){
		for (size_t i=0;i<root_dir.num_directories;i++) {
			filler(buf, root_dir.directories[i].dname, NULL, 0);
			//filler(buf, directory, NULL, 0);

		}
	}else if(flag==1) {
		for (size_t i=0;i<root_dir.num_directories;i++) {
		  compare = root_dir.directories[i]; 
				exist=strncmp(compare.dname,directory,MAX_FILENAME+1); //try using strncmp
				if(exist==0){
					break;
				}	
		}
		if(exist!=0){
			return -ENOENT;
		}
		if(exist==0){
			 fileIndex=compare.n_start_block;
		}
			fseek(fp,fileIndex*BLOCK_SIZE,SEEK_SET);
				struct cs1550_directory_entry file_dir;
				fread (&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);
				//printf("%ld",file_dir.num_files);
				//printf("%ld",file_dir.num_files);
				if(file_dir.num_files==0){
					return -ENOENT;
				}
				for(size_t i=0;i<file_dir.num_files;i++){
					//create a string of file and extension and then add that to filler
					char combine[MAX_FILENAME+MAX_EXTENSION+2];
								strncpy(combine,file_dir.files[i].fname,MAX_FILENAME+1);
								 if(strcmp(file_dir.files[i].fext,"")!=0){
									 strcat(combine,".");
								  strcat(combine,file_dir.files[i].fext);
								 }
					//printf("%ld",flag);
					printf("%s\n", combine);
					//printf("%u",strlen(file_dir.files[i].fext)!=0);
				    	filler(buf, combine, NULL, 0);		
				}
				return 0;
	}

	// Add the subdirectories or files.
	// The +1 hack skips the leading '/' on the filenames.
	//
	//	for (each filename or subdirectory in path) {
	//		filler(buf, filename + 1, NULL, 0);
	//	}

	return 0;
}

/**
 * Creates a directory. Ignore `mode` since we're not dealing with permissions.
 */
static int cs1550_mkdir(const char *path, mode_t mode)
{
		(void) mode;

	char directory[MAX_FILENAME+1];
	char filename[MAX_FILENAME+1];
	char extension[MAX_EXTENSION+1];
	sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);
	// printf("%lu",sizeof(directory));
	// printf("%lu",MAX_FILENAME+1);
	//check the path between 
	//   if(directory[MAX_FILENAME+1]!='\0'){
	//   	return -ENAMETOOLONG;
	//   }
		struct cs1550_root_directory root_dir;
			//FILE * fp;
			//fp = fopen (".disk", "rb+");
			fseek(fp,0,SEEK_SET);
			fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
			if(root_dir.num_directories==MAX_DIRS_IN_ROOT){
				//fclose(fp);
				return -ENOSPC;
			}else{
				strncpy(root_dir.directories[root_dir.num_directories].dname,directory,MAX_FILENAME+1);
				root_dir.directories[root_dir.num_directories].n_start_block=root_dir.last_allocated_block+1;
				root_dir.last_allocated_block++;
				root_dir.num_directories++;
				fseek(fp,0,SEEK_SET);
				fwrite(&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
				//fclose(fp);
				return 0;

			}
		 	//fclose(fp);
		return 0;
}

/**
 * Removes a directory.
 */
static int cs1550_rmdir(const char *path)
{
	(void) path;
				
			
	return 0;
}

/**
 * Does the actual creation of a file. `mode` and `dev` can be ignored.
 */
static int cs1550_mknod(const char *path, mode_t mode, dev_t dev)

{
			(void) mode;
			(void) dev;

	int exist=-1;
	int fileIndex=-1;
	int flag=-1;
	char directory[MAX_FILENAME +1];
	char filename[MAX_FILENAME+1];
	char extension[MAX_EXTENSION+1];
	flag=sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);
		struct cs1550_root_directory root_dir;
			//FILE * fp;
			//fp = fopen (".disk", "rb+"); //make it global
			fseek(fp,0,SEEK_SET);
			fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
				struct cs1550_directory compare;
		for(size_t i=0;i<root_dir.num_directories;i++){
				 compare = root_dir.directories[i]; 
				exist=strncmp(compare.dname,directory,MAX_FILENAME+1);
				if(exist==0){
					break;
				}
			}
			if(exist!=0){
			return -ENOENT;
			}else{
				 fileIndex=compare.n_start_block;
			}
				fseek(fp,fileIndex*BLOCK_SIZE,SEEK_SET);
				struct cs1550_directory_entry file_dir;
				fread (&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);
				if(file_dir.num_files==MAX_FILES_IN_DIR){
					return -ENOSPC; 
				}else{				
				strncpy(file_dir.files[file_dir.num_files].fname,filename,MAX_FILENAME+1);
					//printf(file_dir.files[file_dir.num_files].fname);
				if(flag>1)
				strncpy(file_dir.files[file_dir.num_files].fext,extension,MAX_EXTENSION+1);
					//printf(file_dir.files[file_dir.num_files].fext);
				file_dir.files[file_dir.num_files].n_index_block=root_dir.last_allocated_block +1;
				file_dir.files[file_dir.num_files].fsize=0;
				root_dir.last_allocated_block++;
				//Seek to and read the index block into a variable of type struct cs1550_index_block. 
				//Write the value of the last_allocated_block+1 as the first entry in the index block array.
				// Increment last_allocated_block for the first data block of the file	
				struct cs1550_index_block index_dir;
				fseek(fp,file_dir.files[file_dir.num_files].n_index_block*BLOCK_SIZE,SEEK_SET);
				fread (&index_dir, sizeof(struct cs1550_index_block), 1, fp);
				index_dir.entries[0]=root_dir.last_allocated_block +1;
				root_dir.last_allocated_block++;
				file_dir.num_files++;
				fseek(fp,0,SEEK_SET);
				fwrite(&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
				//seek to the file directory block location and write the file directory back to the file
				fseek(fp,fileIndex*BLOCK_SIZE,SEEK_SET);
				fwrite(&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);
				//seek to the index block location and write the index block back to the file
				fseek(fp,file_dir.files[file_dir.num_files-1].n_index_block*BLOCK_SIZE,SEEK_SET);
				fwrite(&index_dir,sizeof(struct cs1550_index_block), 1, fp);
				//fclose(fp);
					//printf("Mknod is being called:");
				return 0;
				}
				//fclose(fp);
			return -ENOENT;
}

/**
 * Deletes a file.
 */
static int cs1550_unlink(const char *path)
{
	(void) path;
				
	return 0;
}

/**
 * Read `size` bytes from file into `buf`, starting from `offset`.
 */
static int cs1550_read(const char *path, char *buf, size_t size, off_t offset,
		       struct fuse_file_info *fi)
{
				(void) path;
				(void) buf;
				(void) offset;
				(void) fi;


	// (void)buf;
	// (void)offset;
	// int exist=-1;
	// int fileIndex=-1;
	// int flag=-1;
	// 		int eCheck=-1;
	// 		int tExist=-1;
	// char directory[MAX_FILENAME +1];
	// char filename[MAX_FILENAME+1];
	// char extension[MAX_EXTENSION+1];
	// flag=sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);
	// 	struct cs1550_root_directory root_dir;
	// 		//FILE * fp;
	// 		//fp = fopen (".disk", "rb+"); //make it global
	// 		fseek(fp,0,SEEK_SET);
	// 		fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
	// 			struct cs1550_directory compare;
	// 	for(size_t i=0;i<root_dir.num_directories;i++){
	// 			 compare = root_dir.directories[i]; 
	// 			exist=strncmp(compare.dname,directory,MAX_FILENAME+1);
	// 			if(exist==0){
	// 				break;
	// 			}
	// 		}

	// 		if(exist!=0){
	// 		return -ENOENT;
	// 		}else{
	// 			 fileIndex=compare.n_start_block;
	// 		}
	// 			fseek(fp,fileIndex*BLOCK_SIZE,SEEK_SET);
	// 			struct cs1550_directory_entry file_dir;
	// 			struct cs1550_file_entry test;
	// 			fread (&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);			
	// 				for(size_t i=0;i<file_dir.num_files;i++){
	// 					test=file_dir.files[i];
	// 				tExist=strncmp(test.fname,filename,MAX_FILENAME+1);
	// 				//printf(test.fname);
	// 				//printf(filename);
	// 				if(strcmp(test.fext,"")!=0)
	// 				eCheck=strncmp(test.fext,extension,MAX_EXTENSION+1);
	// 				//printf("%ld",eCheck);
	// 				//printf(test.fext);
	// 				//printf(extension);
	// 				if(tExist==0){
	// 					if(strcmp(test.fext,"")!=0){
	// 						if(eCheck==0)
	// 							break;
	// 					}else{
	// 						break;
	// 					}
	// 				}
	// 							}
	// 				if(tExist==0){
	// 				if(strcmp(test.fext,"")!=0){
	// 					if(eCheck!=0)
	// 					return -ENOENT;
	// 				}

	// 				if((size_t)offset>=test.fsize){
	// 					return 0;
	// 				}

	// 			struct cs1550_index_block index_dir;
	// 			fseek(fp,test.n_index_block*BLOCK_SIZE,SEEK_SET);
	// 			fread (&index_dir, sizeof(struct cs1550_index_block), 1, fp);
	// 			 fseek (fp,index_dir.entries[offset/BLOCK_SIZE]*BLOCK_SIZE,SEEK_SET);
	// 				struct cs1550_data_block data_dir;
	// 			 fread(&data_dir,sizeof(struct cs1550_data_block),1,fp);
	// 			//memcpy( offset%blocksize)
	// 			//copy blocksize
	// 			//cap size parameter by remaingin byte in the file 
	// 			// until  size is 0
	// 			size_t effective_size = MIN(test.fsize - ((size_t)offset), size);
	// 			memcpy((void*)buf,data_dir.data[offset%BLOCK_SIZE] ,effective_size);
	// 			}else{

	// 				printf("The file name was not found");
	// 					return -ENOENT;

	// 			}
	// return 0;

	 size =0;


	 return size;
}

/**
 * Write `size` bytes from `buf` into file, starting from `offset`.
 */
static int cs1550_write(const char *path, const char *buf, size_t size,
			off_t offset, struct fuse_file_info *fi)
{
			(void) path;
			(void) buf;
				(void) size;
				(void) offset;
				(void) fi;
	// (void)buf;
	// (void)offset;
	// int exist=-1;
	// int fileIndex=-1;
	// int flag=-1;
	// 		int eCheck=-1;
	// 		int tExist=-1;
	// char directory[MAX_FILENAME +1];
	// char filename[MAX_FILENAME+1];
	// char extension[MAX_EXTENSION+1];
	// flag=sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);
	// 	struct cs1550_root_directory root_dir;
	// 		//FILE * fp;
	// 		//fp = fopen (".disk", "rb+"); //make it global
	// 		fseek(fp,0,SEEK_SET);
	// 		fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
	// 			struct cs1550_directory compare;
	// 	for(size_t i=0;i<root_dir.num_directories;i++){
	// 			 compare = root_dir.directories[i]; 
	// 			exist=strncmp(compare.dname,directory,MAX_FILENAME+1);
	// 			if(exist==0){
	// 				break;
	// 			}
	// 		}

	// 		if(exist!=0){
	// 		return -ENOENT;
	// 		}else{
	// 			 fileIndex=compare.n_start_block;
	// 		}
	// 			fseek(fp,fileIndex*BLOCK_SIZE,SEEK_SET);
	// 			struct cs1550_directory_entry file_dir;
	// 			struct cs1550_file_entry test;
	// 			fread (&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);			
	// 				for(size_t i=0;i<file_dir.num_files;i++){
	// 					test=file_dir.files[i];
	// 				tExist=strncmp(test.fname,filename,MAX_FILENAME+1);
	// 				//printf(test.fname);
	// 				//printf(filename);
	// 				if(strcmp(test.fext,"")!=0)
	// 				eCheck=strncmp(test.fext,extension,MAX_EXTENSION+1);
	// 				//printf("%ld",eCheck);
	// 				//printf(test.fext);
	// 				//printf(extension);
	// 				if(tExist==0){
	// 					if(strcmp(test.fext,"")!=0){
	// 						if(eCheck==0)
	// 							break;
	// 					}else{
	// 						break;
	// 					}
	// 				}
	// 							}
	// 				if(tExist==0){
	// 				if(strcmp(test.fext,"")!=0){
	// 					if(eCheck!=0)
	// 					return -ENOENT;
	// 				}

	// 				if((size_t)offset>=test.fsize){
	// 					return 0;
	// 				}

	// 			struct cs1550_index_block index_dir;
	// 			fseek(fp,test.n_index_block*BLOCK_SIZE,SEEK_SET);
	// 			fread (&index_dir, sizeof(struct cs1550_index_block), 1, fp);
	// 			size_t remaining= size;
	// 			//while
	// 			 fseek (fp,index_dir.entries[offset/BLOCK_SIZE]*BLOCK_SIZE,SEEK_SET);
	// 				struct cs1550_data_block data_dir;
	// 			 fread(&data_dir,sizeof(struct cs1550_data_block),1,fp);
	// 			//memcpy( offset%blocksize)
	// 			//update file size
	// 			//extends more than data block
	// 			//if offset minus 
	// 			//fix below
	// 			size_t effective_size = MIN(test.fsize - ((size_t)offset), size);
	// 			memcpy(data_dir.data[offset%BLOCK_SIZE], (void*)buf,effective_size);
	// 			remaining-=effective_size;
	// 			offset+=BLOCK_SIZE;
				
	// 			}else{

	// 				printf("The file name was not found");
	// 					return -ENOENT;

	// 			}
	return 0;
}

/**
 * Called when a new file is created (with a 0 size) or when an existing file
 * is made shorter. We're not handling deleting files or truncating existing
 * ones, so all we need to do here is to initialize the appropriate directory
 * entry.
 */
static int cs1550_truncate(const char *path, off_t size)
{
	(void) path;
				(void) size;
	return 0;
}

/**
 * Called when we open a file.
 */
static int cs1550_open(const char *path, struct fuse_file_info *fi)
{
	
				(void) fi;
        // If we can't find the desired file, return an error
       // return -ENOENT;

	// Otherwise, return success
	// return 0;
		// Check if the path is a file.
		char directory[MAX_FILENAME +1];
	char filename[MAX_FILENAME+1];
	char extension[MAX_EXTENSION+1];
	int flag;
	flag=sscanf(path, "/%[^/]/%[^.].%s", directory, filename, extension);
		if (flag>1) {
			int fExist=-1;
			struct cs1550_root_directory root_dir;
				fseek(fp,0,SEEK_SET);
			fread (&root_dir, sizeof(struct cs1550_root_directory), 1, fp);
			struct cs1550_directory compare;
			size_t fileIndex=-1;
			for(size_t i=0;i<root_dir.num_directories;i++){
				 compare = root_dir.directories[i]; 
				 //potential issue below 
				fExist=strncmp(compare.dname,directory,MAX_FILENAME+1);
				if(fExist==0){
					break;
				}
			}
				if(fExist==0){
					 fileIndex=compare.n_start_block;
				}else{
					return -ENOENT;
				}
				
				fseek(fp,fileIndex * BLOCK_SIZE,SEEK_SET);
				struct cs1550_directory_entry file_dir;
				struct cs1550_file_entry test;
				fread (&file_dir, sizeof(struct cs1550_directory_entry), 1, fp);
				for(size_t i=0;i<file_dir.num_files;i++){
					test=file_dir.files[i];
					fExist=strncmp(test.fname,filename,MAX_FILENAME+1);
					if(fExist==0){
						break;
					}
				}
				if(fExist==0){
			return 0; // no error
				}else{

					//printf("The file name was not found");
						return -ENOENT;

				}
		}
								return -ENOENT;

}

/**
 * Called when close is called on a file descriptor, but because it might
 * have been dup'ed, this isn't a guarantee we won't ever need the file
 * again. For us, return success simply to avoid the unimplemented error
 * in the debug log.
 */
static int cs1550_flush(const char *path, struct fuse_file_info *fi)
{
	(void) path;
				(void) fi;
	// Success!
	return 0;
}

/**
 * This function should be used to open and/or initialize your `.disk` file.
 */
static void *cs1550_init(struct fuse_conn_info *fi)
{
				(void) fi;
	// Add your initialization routine here.
		fp = fopen (".disk", "rb+");
	return NULL;
}

/**
 * This function should be used to close the `.disk` file.
 */
static void cs1550_destroy(void *args)
{
	(void) args;
		
	// Add your teardown routine here.
	    fclose(fp);
}

/*
 * Register our new functions as the implementations of the syscalls.
 */
static struct fuse_operations cs1550_oper = {
	.getattr	= cs1550_getattr,
	.readdir	= cs1550_readdir,
	.mkdir		= cs1550_mkdir,
	.rmdir		= cs1550_rmdir,
	.read		= cs1550_read,
	.write		= cs1550_write,
	.mknod		= cs1550_mknod,
	.unlink		= cs1550_unlink,
	.truncate	= cs1550_truncate,
	.flush		= cs1550_flush,
	.open		= cs1550_open,
	.init		= cs1550_init,
	.destroy	= cs1550_destroy,
};

/*
 * Don't change this.
 */
int main(int argc, char *argv[])
{
	return fuse_main(argc, argv, &cs1550_oper, NULL);
}
